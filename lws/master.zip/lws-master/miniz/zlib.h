#ifndef __ZLIB_H__
#define __ZLIB_H__
/* Compatiblity header for zlib. */
#define MINIZ_HEADER_FILE_ONLY
#include "miniz.c"

#endif /* __ZLIB_H__ */
